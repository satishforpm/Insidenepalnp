// netlify/edge-functions/social-meta.js
//
// Purpose: WhatsApp / Facebook / Telegram / X etc. crawlers never run
// JavaScript, so the client-side updateSocialMeta() in the page can never
// reach them. This Edge Function runs on Netlify's servers, before the
// response reaches the crawler, and rewrites the <meta> tags in the HTML
// itself when the request is for a specific place (?place=<slug>).
//
// It only rewrites meta tags — nothing else in the page is touched.

const PLACES = [{"slug":"pashupatinath-temple","name":"Pashupatinath Temple","short":"A sacred Hindu temple complex on the banks of the Bagmati River, dedicated to Lord Shiva.","wiki":"Pashupatinath_Temple","image":null},{"slug":"boudhanath-stupa","name":"Boudhanath Stupa","short":"One of the largest spherical stupas in the world, a major centre of Tibetan Buddhism.","wiki":"Boudhanath","image":null},{"slug":"swayambhunath","name":"Swayambhunath","short":"An ancient hilltop stupa overlooking the Kathmandu Valley, known as the 'Monkey Temple'.","wiki":"Swayambhunath","image":null},{"slug":"kathmandu-durbar-square","name":"Kathmandu Durbar Square","short":"The historic royal palace complex of the former Kathmandu Kingdom, with temples and courtyards.","wiki":"Kathmandu_Durbar_Square","image":null},{"slug":"patan-durbar-square","name":"Patan Durbar Square","short":"The palace complex of the former Kingdom of Patan, celebrated for Newar craftsmanship.","wiki":"Patan_Durbar_Square","image":null},{"slug":"bhaktapur-durbar-square","name":"Bhaktapur Durbar Square","short":"The best-preserved of the valley's three durbar squares, centred on the 55-Window Palace.","wiki":"Bhaktapur_Durbar_Square","image":null},{"slug":"changu-narayan","name":"Changu Narayan","short":"One of the oldest Hindu temples in the Kathmandu Valley, dedicated to Vishnu.","wiki":"Changu_Narayan","image":null},{"slug":"budhanilkantha","name":"Budhanilkantha Temple","short":"An open-air shrine famous for its colossal reclining stone statue of Vishnu.","wiki":"Budhanilkantha_Temple","image":null},{"slug":"dakshinkali","name":"Dakshinkali Temple","short":"A revered temple dedicated to the goddess Kali, tucked in a forested gorge.","wiki":"Dakshinkali_Temple","image":null},{"slug":"garden-of-dreams","name":"Garden of Dreams","short":"A neoclassical historic garden in central Kathmandu, restored to its early-20th-century design.","wiki":"Garden_of_Dreams","image":null},{"slug":"kopan-monastery","name":"Kopan Monastery","short":"A Tibetan Buddhist monastery on a hillside above Kathmandu, known for meditation courses.","wiki":"Kopan_Monastery","image":null},{"slug":"phewa-lake","name":"Phewa Lake","short":"Pokhara's iconic lake, reflecting the Annapurna range with the Tal Barahi temple on its island.","wiki":"Phewa_Lake","image":null},{"slug":"begnas-lake","name":"Begnas Lake","short":"A quieter, less-visited lake east of Pokhara, popular for fishing and boating.","wiki":"Begnas_Lake","image":null},{"slug":"davis-falls","name":"Davis Falls","short":"A dramatic waterfall in Pokhara that plunges into an underground tunnel.","wiki":"Davis_Falls","image":null},{"slug":"gupteshwor-mahadev-cave","name":"Gupteshwor Mahadev Cave","short":"A sacred limestone cave near Davis Falls, home to a Shiva shrine.","wiki":"Gupteshwor_Mahadev_Cave","image":null},{"slug":"world-peace-pagoda-pokhara","name":"World Peace Pagoda, Pokhara","short":"A hilltop Buddhist stupa above Phewa Lake, offering panoramic Annapurna views.","wiki":"World_Peace_Pagoda,_Pokhara","image":null},{"slug":"sarangkot","name":"Sarangkot","short":"A hilltop viewpoint above Pokhara famous for sunrise views of the Annapurna and Machapuchare peaks.","wiki":"Sarangkot","image":null},{"slug":"international-mountain-museum","name":"International Mountain Museum","short":"A museum in Pokhara devoted to the culture, history, and mountaineering heritage of Nepal's peaks.","wiki":"International_Mountain_Museum","image":null},{"slug":"muktinath-temple","name":"Muktinath Temple","short":"A high-altitude shrine sacred to both Hindus and Buddhists, in the arid Mustang valley.","wiki":"Muktinath","image":null},{"slug":"jomsom","name":"Jomsom","short":"The administrative headquarters of Mustang, a gateway town on the Annapurna Circuit.","wiki":"Jomsom","image":null},{"slug":"kagbeni","name":"Kagbeni","short":"A medieval walled village at the edge of Upper Mustang, on the old Tibet salt-trade route.","wiki":"Kagbeni","image":null},{"slug":"marpha","name":"Marpha","short":"A whitewashed Thakali village in Mustang known for apple orchards and stone-paved lanes.","wiki":"Marpha","image":null},{"slug":"lo-manthang","name":"Lo Manthang","short":"The walled former capital of the Kingdom of Lo in Upper Mustang.","wiki":"Lo_Manthang","image":null},{"slug":"maya-devi-temple","name":"Maya Devi Temple","short":"The shrine marking the traditional birthplace of Siddhartha Gautama, the Buddha.","wiki":"Maya_Devi_Temple","image":null},{"slug":"lumbini-sacred-garden","name":"Lumbini Sacred Garden","short":"The core UNESCO-listed sacred zone of Lumbini, encompassing the Buddha's birthplace.","wiki":"Lumbini","image":null},{"slug":"ashoka-pillar","name":"Ashoka Pillar, Lumbini","short":"A stone pillar erected by Emperor Ashoka in the 3rd century BCE, marking Buddha's birthplace.","wiki":"Pillars_of_Ashoka","image":null},{"slug":"tilaurakot","name":"Tilaurakot","short":"Archaeological ruins widely identified with ancient Kapilavastu, where Buddha spent his youth.","wiki":"Tilaurakot","image":null},{"slug":"everest-base-camp","name":"Everest Base Camp","short":"The staging point on the south side of Mount Everest for climbing expeditions, at the foot of the Khumbu Icefall.","wiki":"Everest_Base_Camp","image":null},{"slug":"mount-everest","name":"Mount Everest","short":"Earth's highest mountain above sea level, straddling the border of Nepal and Tibet.","wiki":"Mount_Everest","image":null},{"slug":"sagarmatha-national-park","name":"Sagarmatha National Park","short":"A high-altitude national park surrounding Mount Everest, home to Sherpa culture and rare wildlife.","wiki":"Sagarmatha_National_Park","image":null},{"slug":"namche-bazaar","name":"Namche Bazaar","short":"The bustling Sherpa trading town and main gateway for Everest region trekkers.","wiki":"Namche_Bazaar","image":null},{"slug":"gokyo-lakes","name":"Gokyo Lakes","short":"A chain of turquoise glacial lakes in the Everest region, among the highest freshwater lake systems in the world.","wiki":"Gokyo_Lakes","image":null},{"slug":"chitwan-national-park","name":"Chitwan National Park","short":"Nepal's first national park, protecting one-horned rhinoceros, Bengal tigers, and Terai wetlands.","wiki":"Chitwan_National_Park","image":null},{"slug":"bardia-national-park","name":"Bardia National Park","short":"The largest and wildest national park in the Terai, known for tigers and wild elephants.","wiki":"Bardia_National_Park","image":null},{"slug":"langtang-national-park","name":"Langtang National Park","short":"Nepal's first Himalayan national park, home to the Langtang valley and Tamang villages.","wiki":"Langtang_National_Park","image":null},{"slug":"rara-national-park","name":"Rara National Park","short":"A remote park in far-western Nepal built around Rara Lake, the country's largest lake.","wiki":"Rara_National_Park","image":null},{"slug":"rara-lake","name":"Rara Lake","short":"Nepal's largest lake, prized for its deep-blue water inside Rara National Park.","wiki":"Rara_Lake","image":null},{"slug":"shey-phoksundo-national-park","name":"Shey Phoksundo National Park","short":"Nepal's largest national park, containing the turquoise Phoksundo Lake in remote Dolpa.","wiki":"Shey_Phoksundo_National_Park","image":null},{"slug":"khaptad-national-park","name":"Khaptad National Park","short":"A rolling highland park in far-western Nepal known for meadows and a revered ashram.","wiki":"Khaptad_National_Park","image":null},{"slug":"makalu-barun-national-park","name":"Makalu Barun National Park","short":"A national park protecting the area around Makalu, the world's fifth-highest peak.","wiki":"Makalu_Barun_National_Park","image":null},{"slug":"shivapuri-nagarjun-national-park","name":"Shivapuri Nagarjun National Park","short":"A forested watershed park on the northern rim of the Kathmandu Valley.","wiki":"Shivapuri_Nagarjun_National_Park","image":null},{"slug":"gosaikunda","name":"Gosaikunda","short":"A sacred high-altitude lake in the Langtang region, the site of an annual Hindu pilgrimage.","wiki":"Gosaikunda","image":null},{"slug":"tilicho-lake","name":"Tilicho Lake","short":"One of the highest lakes in the world, ringed by the Annapurna and Tilicho peaks.","wiki":"Tilicho_Lake","image":null},{"slug":"manakamana-temple","name":"Manakamana Temple","short":"A hilltop temple to the wish-fulfilling goddess Bhagwati, reached by a cable car.","wiki":"Manakamana_Temple","image":null},{"slug":"janaki-mandir","name":"Janaki Mandir","short":"A grand white marble temple in Janakpur, associated with the goddess Sita.","wiki":"Janaki_Mandir","image":null},{"slug":"pathibhara-temple","name":"Pathibhara Devi Temple","short":"A revered hilltop shrine to the goddess Pathibhara, on the Kanchenjunga trekking trail.","wiki":"Pathibhara_Devi_Temple","image":null},{"slug":"halesi-mahadev","name":"Halesi Mahadev","short":"A cave shrine to Shiva sacred to both Hindus and the Kirati and Buddhist communities.","wiki":"Halesi_Mahadev","image":null},{"slug":"gorkha-durbar","name":"Gorkha Durbar","short":"The hilltop palace-fort of Prithvi Narayan Shah, founder of unified Nepal.","wiki":"Gorkha_Durbar","image":null},{"slug":"nuwakot-durbar","name":"Nuwakot Durbar","short":"A seven-storey historic palace that served as a strategic base during the unification of Nepal.","wiki":"Nuwakot_Durbar","image":null}];

const DEFAULT_TITLE = "Inside Nepal — Discover the Beauty, History & Culture of Nepal";
const DEFAULT_DESC = "A static, no-database guide to Nepal's temples, mountains, lakes, national parks, palaces and heritage sites.";

function escapeAttr(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function replaceMetaContent(html, id, value) {
  const re = new RegExp('(<meta id="' + id + '"[^>]*content=")[^"]*(")');
  return html.replace(re, '$1' + escapeAttr(value) + '$2');
}

function replaceLinkHref(html, id, value) {
  const re = new RegExp('(<link id="' + id + '"[^>]*href=")[^"]*(")');
  return html.replace(re, '$1' + escapeAttr(value) + '$2');
}

async function resolveImage(place, origin) {
  if (place.image) return place.image;
  if (place.wiki) {
    try {
      const res = await fetch(
        "https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(place.wiki),
        { headers: { "User-Agent": "InsideNepalSocialPreview/1.0" } }
      );
      if (res.ok) {
        const data = await res.json();
        const src =
          (data.originalimage && data.originalimage.source) ||
          (data.thumbnail && data.thumbnail.source) ||
          null;
        if (src) return src;
      }
    } catch (_e) {
      // fall through to default image below
    }
  }
  return origin + "/og-image.jpg";
}

export default async (request, context) => {
  const url = new URL(request.url);
  const slug = url.searchParams.get("place");

  const response = await context.next();

  // No ?place= param, or not an HTML response (e.g. an asset) -> leave as-is.
  const contentType = response.headers.get("content-type") || "";
  if (!slug || !contentType.includes("text/html")) {
    return response;
  }

  const place = PLACES.find((p) => p.slug === slug);
  if (!place) return response;

  const title = place.name + " — Inside Nepal";
  const desc = place.short || DEFAULT_DESC;
  const image = await resolveImage(place, url.origin);
  const pageUrl = url.toString();

  let html = await response.text();

  html = html.replace(/<title>[^<]*<\/title>/, "<title>" + escapeAttr(title) + "</title>");
  html = replaceMetaContent(html, "ogTitle", title);
  html = replaceMetaContent(html, "ogDescription", desc);
  html = replaceMetaContent(html, "ogImage", image);
  html = replaceMetaContent(html, "ogUrl", pageUrl);
  html = replaceMetaContent(html, "twitterTitle", title);
  html = replaceMetaContent(html, "twitterDescription", desc);
  html = replaceMetaContent(html, "twitterImage", image);
  html = replaceLinkHref(html, "canonicalLink", pageUrl);

  return new Response(html, response);
};

export const config = { path: "/" };
